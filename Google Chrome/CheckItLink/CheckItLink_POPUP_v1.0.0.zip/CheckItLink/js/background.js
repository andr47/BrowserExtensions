// background.js


/*
*	Создаем пункты в контекстном меню
*/
function createMenu(){
	/*
	*	создаем корневой пункт меню
	*/
	var root = chrome.contextMenus.create({
		title: chrome.i18n.getMessage("addUrlToBookmarks_menu_root"), 
		contexts: ["link", "page"],
		id: "addUrlToBookmarks"
	});
	/*
	*	создаем вложенные пункты
	*/
	var item1 = chrome.contextMenus.create({
		title: chrome.i18n.getMessage("addUrlToBookmarks_menu_item1"), 
		contexts: ["page"],
		id: "addUrl_item1",
		parentId: root
	});
	var item2 = chrome.contextMenus.create({
		title: chrome.i18n.getMessage("addUrlToBookmarks_menu_item2"), 
		contexts: ["page"],
		id: "addUrl_item2", 
		parentId: root
	});
	var item3 = chrome.contextMenus.create({
		title: chrome.i18n.getMessage("addUrlToBookmarks_menu_item3"), 
		contexts: ["link"],
		id: "addUrl_item3",
		parentId: root
	});
}

/*
*	Обработчик клика по пункту меню
*/
function addUrlToBookmarks(info, tab){
	//alert("info: " + JSON.stringify(info));
	//alert("tab: " + JSON.stringify(tab));
	switch(info.menuItemId){
		/*
		*	если нажат пункт меню "Добавить текущую страницу"
		*/
		case "addUrl_item1":
			chrome.windows.getCurrent(function(w){
				chrome.tabs.getSelected(w.id,function(t){
					var height, width;
					var top = w.height / 2 - 250;
					var left = w.width / 2 - 275;
					localStorage["TITLE"] = t.title;
					localStorage["URL"] = t.url;
					var newWin = window.open("popup.html", "extension_popup", "width=550,height=500,top="+top+",left="+left+",status=no,scrollbars=yes,resizable=no");
					newWin.focus();
				});
			});
			break;
		/*
		*	если нажат пункт меню "Экспорт"
		*/
		case "addUrl_item2":
			chrome.windows.getCurrent(function(w){
				chrome.tabs.getSelected(w.id,function(t){
					var height, width;
					var top = w.height / 2 - 250;
					var left = w.width / 2 - 275;
					localStorage["TITLE"] = t.title;
					localStorage["URL"] = t.url;
					localStorage["tempData"] = "export";
					var newWin = window.open("popup.html", "extension_popup", "width=550,height=500,top="+top+",left="+left+",status=no,scrollbars=yes,resizable=no");
					newWin.focus();
				});
			});
			break;
		/*
		*	если нажат пункт меню "Добавить ссылку под курсором"
		*/
		case "addUrl_item3":
			chrome.windows.getCurrent(function(w){
				chrome.tabs.getSelected(w.id,function(t){
					var height, width;
					var top = w.height / 2 - 250;
					var left = w.width / 2 - 275;
					localStorage["TITLE"] = info.linkUrl;
					localStorage["URL"] = info.linkUrl;
					var newWin = window.open("popup.html", "extension_popup", "width=550,height=500,top="+top+",left="+left+",status=no,scrollbars=yes,resizable=no");
					newWin.focus();
				});
			});
			break;
	}
}

/*
*	вешаем обработчик на вызов пункта меню
*/
chrome.contextMenus.onClicked.addListener(addUrlToBookmarks);

/*
*	При обновлении вкладки показываем или скрываем иконку расширения и пункты меню.
*	Разрешаем работу только на страницах с протоколом http, https, ftp
*/
chrome.tabs.onUpdated.addListener(function(id,info,tab){
	var re = new RegExp(/^(https?)|(ftp)\:\/\/.*/i);
	if (re.test(tab.url)){
		chrome.pageAction.show(id);
		createMenu();
	}
	else{
		chrome.pageAction.hide(id);
	}
});


/*
*	Функция отправляет запрос на сервер и показывает уведомления если они есть
*/
function getNotify(){
	if(localStorage["notifyFlag"] === "true"){
		var params = {
			SECRET_KEY: localStorage["SECRET_KEY"], 
			action: serverActions.GET_NOTIFICATIONS
		};
		
		$.ajax({
			type: Options.defaultMethod,
			url: Options.defaultURL,
			dataType: 'json',
			data: {request: JSON.stringify(params)},
			error: function(jqXHR, textStatus, errorThrown){
				alert(chrome.i18n.getMessage("AJAXError"));
			},
			// перед отправкой проверяем есть ли подключение к интернету и если нет, то запрос не произойдет
			beforeSend: function(jqXHR, settings ){return navigator.onLine;},
			// обработаем ответ сервера
			success: function(res){
				// если код 200, то SECRET_KEY верный и уведомление получено
				if(res.response.code == Options.response.code.ok){
					// вывод уведомления
					var notification = new Notification(res.response.title, {
						tag : Options.currentNotifyId,
						icon: 'img/icon/icon-48.png',
						body: res.response.message
					});

					notification.onclick = function () {
						window.open(Options.baseURL);      
					};
				}
			}
		});
	}
}

/*
*	По таймеру получаем уведомления с сайта
*/
chrome.alarms.create("getNotify", {periodInMinutes: parseInt(localStorage["notifyInterval"])});
chrome.alarms.onAlarm.addListener(function(alarm) {
	if(alarm.name == "getNotify"){
		getNotify();
	}
});

/*
*	Устанавливаем ссылку, которая откроется после установки расширения
*/
chrome.runtime.onInstalled.addListener(function(details){
	if(Options.InstallURL === true){
		window.open(Options.InstallURL);
	}
});

/*
*	Устанавливаем ссылку, которая откроется после удаления расширения
*/
if(Options.UninstallURL === true){
	chrome.runtime.setUninstallURL(Options.UninstallURL);
}