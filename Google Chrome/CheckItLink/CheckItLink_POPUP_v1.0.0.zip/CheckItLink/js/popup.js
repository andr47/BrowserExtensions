// content.js

/*
*	Пример отправки сообщения скрипту background.js
*	chrome.extension.sendMessage({action:'someaction'});
*/

/*
*	Функция отправляет сообщения в content.js с параметром params, который содержит объект
*/
function sendAction(params){
	chrome.extension.sendMessage(params);
}

/*
*	Запускаем экспорт
*/
function goExport(){
	chrome.bookmarks.getTree(getAllBookmarks);
}

/*
*	Функция обхода дерева закладок
*/
function recursiveJSON2ARRAY(obj, parent){
	$.each(obj, function(i, v){
		if(v.children && 'object' === typeof v.children && Object.keys(v.children).length > 0){
			var parentname = v.title;
			$.each(v.children, function(i, child){
				if(child.url){
					Options.marks.data.push({
						parentname: parent+'->'+parentname, 
						date: child.dateAdded, 
						name: child.title, 
						url: child.url
					});
				}
				else{
					recursiveJSON2ARRAY(v.children, parent+"->"+parentname);
				}
			});
		}
		else{
			if(v.url){
				Options.marks.data.push({
					parentname: parent, 
					date: v.dateAdded,  
					name: v.title, 
					url: v.url
				});
			}
		}
	});
}

/*
*	Функция получения дерева закладок.
*/
function getAllBookmarks(tree){
	// запускаем парсер закладок
	$.each(tree, function(i, childrenElement){
		if(childrenElement.children && 'object' === typeof childrenElement.children){
			recursiveJSON2ARRAY(childrenElement.children, chrome.i18n.getMessage("root_categories_name"));
		}
	});
	
	// удаляем дубликаты из массива
	var arr = {};
	for ( var i=0, len=Options.marks.data.length; i < len; i++ )
		arr[Options.marks.data[i]['date']] = Options.marks.data[i];
	Options.marks.data = new Array();
	for ( var key in arr )
		Options.marks.data.push(arr[key]);
	
	// делаем экспорт на сервер
	$.ajax({
		type: Options.defaultMethod,
		url: Options.defaultURL,
		dataType: 'json',
		data: {request: JSON.stringify({SECRET_KEY: localStorage["SECRET_KEY"], action: serverActions.EXPORT, data: Options.marks.data})},
		error: function(jqXHR, textStatus, errorThrown){
			$("#my_chrome_app_div_spinner").children().remove();
			$('#add_url_alert section:last-child').html(chrome.i18n.getMessage("AJAXError"));
			$("#add_url_alert").removeClass(".alert-success").addClass(".alert-danger");
			$("#add_url_alert").show();
			alert(chrome.i18n.getMessage("AJAXError"));
		},
		beforeSend: function(jqXHR, settings ){return navigator.onLine;},
		// обработаем ответ сервера
		success: function(res){
			$("#my_chrome_app_div_spinner").children().remove();
			// если код 200, то экспорт удался
			if(res.response.code == Options.response.code.ok){
				$("#add_url_alert").removeClass(".alert-danger").addClass(".alert-success");
				$('#add_url_alert section:last-child').html(res.response.message);
			}
			else if(res.response.code == Options.response.code.error){
				$("#add_url_alert").removeClass(".alert-success").addClass(".alert-danger");
				$('#add_url_alert section:last-child').html(res.response.message);
			}
			$("#add_url_alert").show();
		}
	});
}

/*
*	Функция открытия формы добавления ссылки
*/
function showFormAddURL(){
	var protocol = localStorage["protocol"];
	$('#form_container section:last-child').children().remove();
	$('#form_container section:last-child').append(extForms.addUrlForm.html);
	$('#addurl-form_description').focus();
	$('#addurl-form_title').val(localStorage["TITLE"]);
	$('#addurl-form_url').val(localStorage["URL"]);
	/*
	*	Здесь надо послать запрос серверу для получения списка категорий и вставить список в форму
	*/
	if(protocol != "https:") {
		$.ajax({
			type: Options.defaultMethod,
			url: Options.defaultURL,
			dataType: 'json',
			data: {request: JSON.stringify({SECRET_KEY: localStorage["SECRET_KEY"], action: serverActions.GET_CATEGORIES})},
			error: function(jqXHR, textStatus, errorThrown){
				var html = '';
				$.each(Options.staticCategories, function(i, val){
					html += '<option value="'+val.id+'">'+val.name+'</option>';
				});
				$('#addurl-form_categori_id').children().remove();
				$('#addurl-form_categori_id').append(html);
				alert(chrome.i18n.getMessage("AJAXError"));
			},
			beforeSend: function(jqXHR, settings ){return navigator.onLine;},
			// обработаем ответ сервера
			success: function(res){
				// если код 200, то список получен
				if(res.response.code == Options.response.code.ok){
					var html = '';
					$.each(res.response.categories, function(i, val){
						html += '<option value="'+val.id+'">'+val.cat_name+'</option>';
					});
					$('#addurl-form_categori_id').children().remove();
					$('#addurl-form_categori_id').append(html);
				}
				// если код 401, то ошибка получения списка
				else if(res.response.code == Options.response.code.error){
					var html = '';
					$.each(Options.staticCategories, function(i, val){
						html += '<option value="'+val.id+'">'+val.name+'</option>';
					});
					$('#addurl-form_categori_id').children().remove();
					$('#addurl-form_categori_id').append(html);
				}
			}
		});
	}
	else {
		var html = '';
		$.each(Options.staticCategories, function(i, val){
			html += '<option value="'+val.id+'">'+val.name+'</option>';
		});
		$('#addurl-form_categori_id').children().remove();
		$('#addurl-form_categori_id').append(html);
	}

	/*
	*	Здесь надо послать запрос серверу для получения списка хэштегов и вставить список в Options.hashtags
	*/
	if(protocol != "https:") {
		$.ajax({
			type: Options.defaultMethod,
			url: Options.defaultURL,
			dataType: 'json',
			data: {request: JSON.stringify({SECRET_KEY: localStorage["SECRET_KEY"], action: serverActions.GET_HASHTAGS})},
			error: function(jqXHR, textStatus, errorThrown){
				Options.hashtags = [];
				alert(chrome.i18n.getMessage("AJAXError"));
			},
			beforeSend: function(jqXHR, settings ){return navigator.onLine;},
			// обработаем ответ сервера
			success: function(res){
				// если код 200, то список получен
				if(res.response.code == Options.response.code.ok){
					var hashtags = res.response.hashtags;
					Options.hashtags = [];
					$.each(hashtags, function(i, val){
						Options.hashtags.push(val.name);
					});
					$('#addurl-form_hashtag').meta_input(
						{
							data: Options.hashtags, 
							multiple: true, 
							customValues: true, 
							select: false,
							selectPlaceholder: "Input hashtag"
						}
					);
				}
				// если код 401, то ошибка получения списка
				else if(res.response.code == Options.response.code.error){
					$('#addurl-form_hashtag').meta_input(
					{
						data: Options.staticHashtags, 
						multiple: true, 
						customValues: true, 
						select: false,
						selectPlaceholder: "Input hashtag"
					}
		);
				}
			}
		});
	}
	else {
		$('#addurl-form_hashtag').meta_input(
			{
				data: Options.staticHashtags, 
				multiple: true, 
				customValues: true, 
				select: false,
				selectPlaceholder: "Input hashtag"
			}
		);
	}

	/*
	*	Вешаем на кнопку "Добавить" обработчик, который отправит форму на сервер
	*/
	$('#addurl-form_submit_addurl-form').on('click', function(){
		$("#my_chrome_app_div_spinner").children().remove();
		$("#my_chrome_app_div_spinner").append('<img id="my_chrome_app_spinner" />');
		var fields = $("#addurl-form").serializeArray();
		var params = {
			SECRET_KEY: localStorage["SECRET_KEY"], 
			action: serverActions.ADDURL, 
			args: {
				hashtag: []
			}
		};
		$.each(fields, function(i, val){
			switch(val.name){
				case "categori_id":
					params.args.categori_id = val.value;
					break;
				case "title":
					params.args.title = val.value;
					break;
				case "description":
					params.args.description = val.value;
					break;
				case "url":
					params.args.url = val.value;
					break;
				case "hashtag":
					/*
					*	Здесь обработка хэштегов.
					*	Можно обработать строку, если она содержит запятые и занести каждый элемент в массив.
					*	Но мне лень )))
					*/
					if($.trim(val.value).length > 0){
						params.args.hashtag.push($.trim(val.value));
					}
					break;
				case "status":
					params.args.status = val.value;
					break;
				default:
					break;
			}
		});
		var sendParams = {
			fields: params,
			action: extActions.sendForm
		};
		sendAction(sendParams);
	});

	/*
	*	Вешаем на кнопку "Экспорт" обработчик, который отправит в 
	*	background.js команду для запуска экспорта
	*/
	$('#addurl-form_go_export_addurl-form').on('click', function(){
		$("#my_chrome_app_div_spinner").children().remove();
		$("#my_chrome_app_div_spinner").append('<img id="my_chrome_app_spinner" />');
		goExport();
	});
}

/*
*	Функция открытия формы ввода SECRET_KEY
*/
function showFormSecretKey(){
	$('#form_container section:last-child').children().remove();
	$('#form_container section:last-child').append(extForms.addSecretKeyForm.html);
	$('#secret_key-form_SECRET_KEY').focus();
	/*
	*	Вешаем обработчик на кнопку "Показать пароль"
	*/
	$('#show_password').on('mousedown', function(){
		$('#secret_key-form_SECRET_KEY').attr({"type": "text"});
	});
	$('#show_password').on('mouseup', function(){
		$('#secret_key-form_SECRET_KEY').attr({"type": "password"});
		$('#secret_key-form_SECRET_KEY').focus();
	});
	/*
	*	Вешаем обработчик на кнопку Запомнить
	*/
	$('#secret_key-form_submit_secret_key-form').on('click', function(){
		$("#my_chrome_app_div_spinner").html('<img id="my_chrome_app_spinner" />');
		var fields = $("#secret_key-form").serializeArray();
		var params = {
			SECRET_KEY: "",
			action: serverActions.LOGIN
		};
		$.each(fields, function(i, val){
			switch(val.name){
				case "SECRET_KEY":
					params.SECRET_KEY = val.value;
					break;
				default:
					break;
			}
		});
		var sendParams = {
			fields: params,
			action: extActions.sendFormSecretKey
		};
		sendAction(sendParams);
	});
}

$(document).ready(function(){
	/*
	*	Когда страница открывается в новом окне (по клику в меню), то скролим ее вверх
	*	ХЗ почему так, баг какой-то
	*/
	$("html, body").animate({ scrollTop: 0 }, 600);
	$("title").text(chrome.i18n.getMessage("extension_name"));

	chrome.windows.getCurrent(function(w){
		chrome.tabs.getSelected(w.id,function(t){
			//alert(JSON.stringify(w));
			//alert(JSON.stringify(t));
			switch(w.type){
				case "popup":
					/*
					*	Страница открыта в новом окне (по клику в меню)
					*/
					break;
				case "normal":
					localStorage["TITLE"] = t.title;
					localStorage["URL"] = t.url;
					break;
				default:
					break;
			}
			/*
			*	Если в options.js флаг стоит в true, то работает костыль ))
			*	Костыль позволяет работать расширению если страница загружена по https, а обработчик доступен по http
			*/
			if(Options.testHTTPS === true){
				localStorage["protocol"] = t.url.substring(0, 6);
			}
			else{
				localStorage["protocol"] = "http";
			}
			/*
			*	Проверяем есть ли подключение к Интернету
			*/
			if (!navigator.onLine){
				$('#form_container section:last-child').children().remove();
				$('#form_container section:last-child').append(extForms.NetStatusAlert.html);
			}
			else{
				/*
				*	Если SECRET_KEY есть, то показываем форму для добавления ссылки
				*/
				if(localStorage["SECRET_KEY"]){
					showFormAddURL();
				}
				/*
				*	Если SECRET_KEY нет, то показываем форму для ввода SECRET_KEY
				*/
				else{
					showFormSecretKey();
				}
			}
		});
	});

	/*
	*	Обработчики кнопок тулбара в popup
	*/
	$("#open_options_page").on('click', function(){
		chrome.runtime.openOptionsPage();
	});

	$("#open_donate_page").on('click', function(){
		var newWin = window.open(Options.donateURL);
	});

	$("#open_about_page").on('click', function(){
		if(Options.aboutURLinNewTab){
			window.open(Options.aboutURL);
		}
		else{
			chrome.windows.getCurrent(function(w){
				chrome.tabs.getSelected(w.id,function(t){
					var height, width;
					var top = w.height / 2 - 200;
					var left = w.width / 2 - 200;
					var newWin = window.open(Options.aboutURL, "extension_popup", "width=400,height=400,top="+top+",left="+left+",status=no,scrollbars=yes,resizable=no");
					newWin.focus();
				});
			});
		}
	});

	$("#open_home_page").on('click', function(){
		window.open(Options.baseURL);
	});

	$("#change_key_button").on('click', function(){
		delete localStorage["SECRET_KEY"];
		showFormSecretKey();
	});

	$('#open_options_page').attr({"title": chrome.i18n.getMessage("open_options_page_title")});
	$('#open_donate_page').attr({"title": chrome.i18n.getMessage("open_donate_page_title")});
	$('#open_about_page').attr({"title": chrome.i18n.getMessage("open_about_page_title")});
	$('#open_home_page').attr({"title": chrome.i18n.getMessage("open_home_page_title").replace(/%s/ig, Options.baseURL)});
	$('#change_key_button').attr({"title": chrome.i18n.getMessage("change_key_button_title")});
	
	/*
	*	Перехватываем событие submit для наших форм
	*/
	$("#addurl-form").on('submit', function(){
		return false;
	});
	$("#secret_key-form").on('submit', function(){
		return false;
	});
	
	/*
	*	Если существует localStorage["tempData"], значит нажат пункт меню "Экспорт"
	*	Поэтому нажимаем на соответствующую кнопку
	*/
	if(localStorage["tempData"] && localStorage["tempData"] === "export"){
		setTimeout(function() { $('#addurl-form_go_export_addurl-form').click() }, 1000);
		delete localStorage["tempData"];
	}
	/* 
	*	Обработчик ответа от background.js
	*/
	chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
		switch (msg.action) {
			/*
			*	Отправляем ссылку на сервер
			*/
			case extActions.sendForm:
				/*
				*	Отправляем форму добавления ссылки на сервер
				*/
				var fields = msg.fields;
				
				$.ajax({
					type: Options.defaultMethod,
					url: Options.defaultURL,
					dataType: 'json',
					data: {request: JSON.stringify(fields)},
					error: function(jqXHR, textStatus, errorThrown){
						alert(chrome.i18n.getMessage("AJAXError"));
						sendAction({
							action: extActions.sendFormError, 
							message: chrome.i18n.getMessage("AJAXError")
						});
					},
					beforeSend: function(jqXHR, settings ){return navigator.onLine;},
					// обработаем ответ сервера
					success: function(res){
						// если код 200, то ссылка добавлена
						if(res.response.code == Options.response.code.ok){
							sendAction({
								action: extActions.sendFormSuccess, 
								message: res.response.message
							});
						}
						// если код 401, то ошибка добавления ссылки
						else if(res.response.code == Options.response.code.error){
							sendAction({
								action: extActions.sendFormError, 
								message: res.response.message
							});
						}
					}
				});
				break;
			/*
			*	Отправляем SECRET_KEY на сервер
			*/
			case extActions.sendFormSecretKey:
				/*
				*	Отправляем форму ввода SECRET_KEY на сервер
				*/
				var fields = msg.fields;
				
				$.ajax({
					type: Options.defaultMethod,
					url: Options.defaultURL,
					dataType: 'json',
					data: {request: JSON.stringify(fields)},
					error: function(jqXHR, textStatus, errorThrown){
						alert(chrome.i18n.getMessage("AJAXError"));
						sendAction({
							action: extActions.sendFormSecretKeyError, 
							message: chrome.i18n.getMessage("AJAXError")
						});
					},
					beforeSend: function(jqXHR, settings ){return navigator.onLine;},
					// обработаем ответ сервера
					success: function(res){
						// если код 200, то SECRET_KEY верный
						if(res.response.code == Options.response.code.ok){
							localStorage["SECRET_KEY"] = fields.SECRET_KEY;
							sendAction({
								action: extActions.sendFormSecretKeySuccess, 
								message: res.response.message
							});
						}
						// если код 401, то ошибка SECRET_KEY
						else if(res.response.code == Options.response.code.error){
							sendAction({
								action: extActions.sendFormSecretKeyError, 
								message: res.response.message
							});
						}
					}
				});
				break;
			/*
			*	Выводим уведомление об успешном добавлении ссылки
			*/
			case extActions.sendFormSuccess:
				//alert("Передан action:"+msg.action+"\r\nУведомление об успешном добавлении ссылки: "+msg.message);
				$("#my_chrome_app_div_spinner").children().remove();
				$('#add_url_alert section:last-child').html(msg.message);
				$("#add_url_alert").show();
				$("#add_url_alert").removeClass(".alert-danger").addClass(".alert-success");
				break;
			/*
			*	Выводим уведомление об ошибке добавления ссылки
			*/
			case extActions.sendFormError:
				//alert("Передан action:"+msg.action+"\r\nУведомление об ошибке добавления ссылки: "+msg.message);
				$("#my_chrome_app_div_spinner").children().remove();
				$('#add_url_alert section:last-child').html(msg.message);
				$("#add_url_alert").show();
				$("#add_url_alert").removeClass(".alert-success").addClass(".alert-danger");
				break;
			/*
			*	Выводим уведомление об успешном вводе SECRET_KEY
			*/
			case extActions.sendFormSecretKeySuccess:
				//alert("Передан action:"+msg.action+"\r\nУведомление об успешном вводе SECRET_KEY: "+msg.message);
				$("#my_chrome_app_div_spinner").children().remove();
				$('#secret_key_alert section:last-child').html(msg.message);
				$("#secret_key_alert").show();
				$("#secret_key_alert").removeClass(".alert-danger").addClass(".alert-success");
				/*
				*	Ну а коли у нас SECRET_KEY передан верно, то не грех и показать форму добавления ссылки ))
				*	Через три секунды после того, как прошла авторизация
				*/
				chrome.alarms.create("AuthorizeSuccess", {when: Date.now()+3000});
				chrome.alarms.onAlarm.addListener(function(alarm){
					if(alarm.name == "AuthorizeSuccess"){
						showFormAddURL();
						chrome.alarms.clear("AuthorizeSuccess");
					}
				});
				break;
			/*
			*	Выводим уведомление об ошибке ввода SECRET_KEY
			*/
			case extActions.sendFormSecretKeyError:
				//alert("Передан action:"+msg.action+"\r\nУведомление об ошибке ввода SECRET_KEY: "+msg.message);
				$("#my_chrome_app_div_spinner").children().remove();
				$('#secret_key_alert section:last-child').html(msg.message);
				$("#secret_key_alert").show();
				$("#secret_key_alert").removeClass(".alert-success").addClass(".alert-danger");
				break;
			/*
			*	Обработаем неизвестный action на всякий случай
			*/
			default:
				alert(msg.action+', '+chrome.i18n.getMessage("error_action"));
				break;
		}
	});

});